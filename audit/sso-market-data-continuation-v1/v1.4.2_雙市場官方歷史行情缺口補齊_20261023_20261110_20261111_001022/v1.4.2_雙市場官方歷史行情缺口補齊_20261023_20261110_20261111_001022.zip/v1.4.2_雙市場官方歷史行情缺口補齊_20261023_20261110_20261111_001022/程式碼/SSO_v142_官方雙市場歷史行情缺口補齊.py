# -*- coding: utf-8 -*-
"""SSO_Market_Data_Continuation_TWSE_TPEX v1.4.2
補齊 2026-10-23 至 2026-11-10 的 TWSE / TPEx 官方逐日歷史行情。
唯讀既有資料，只新增日期區間專屬封存；不修改正式資料庫、不回測、不選股、不碰 main。
"""
from __future__ import annotations

import os, re, csv, io, json, gzip, time, hashlib, zipfile, base64, traceback
from pathlib import Path
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
from urllib.parse import quote

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

VERSION = "v1.4.2"
START_DATE = date(2026, 10, 23)
END_DATE = date(2026, 11, 10)
TZ = ZoneInfo("Asia/Taipei")
RUN_TIME = datetime.now(TZ)
STAMP = RUN_TIME.strftime("%Y%m%d_%H%M%S")
PROJECT_ROOT = Path("/content/drive/MyDrive/看股最速適")
CONTINUATION_ROOT = PROJECT_ROOT / "SSO_Market_Data_Continuation_TWSE_TPEX_v1"
OUTPUT_NAME = f"{VERSION}_雙市場官方歷史行情缺口補齊_{START_DATE:%Y%m%d}_{END_DATE:%Y%m%d}_{STAMP}"
REPO = "CHLINX/sso"
EXPECTED_MAIN_SHA = "aaabc2433fb5df2bb68af06461178305d6bd30d1"
TWSE_URL = "https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX"
TPEX_URL = "https://www.tpex.org.tw/web/stock/aftertrading/otc_quotes_no1430/stk_wn1430_result.php"
MIN_ROWS = {"TWSE": 500, "TPEX": 500}
TIMEOUT = (20, 120)
SLEEP_SECONDS = 0.35

# 2026-10-26 為臺灣光復暨金門古寧頭大捷紀念日補假，兩市場休市。
# TWSE：https://www.twse.com.tw/holidaySchedule/holidaySchedule?response=html
# TPEx：https://www.tpex.org.tw/storage/eb_data/11411/114007545811-1.pdf
OFFICIAL_MARKET_CLOSED = {
    date(2026, 10, 26): {
        "TWSE": "臺灣光復暨金門古寧頭大捷紀念日補假；依 TWSE 115 年市場開休市日期",
        "TPEX": "臺灣光復暨金門古寧頭大捷紀念日補假；依 TPEx 115 年市場開休市日期公告",
    }
}

CODE_KEYS = ["證券代號", "證券代碼", "股票代號", "代號", "Code", "SecuritiesCompanyCode"]
NAME_KEYS = ["證券名稱", "股票名稱", "名稱", "Name", "CompanyName", "SecuritiesCompanyName"]
VOLUME_KEYS = ["成交股數", "成交量", "TradeVolume", "TradingShares"]
VALUE_KEYS = ["成交金額", "成交金額(元)", "成交金額（元）", "TradingValue", "TradeValue"]
COUNT_KEYS = ["成交筆數", "交易筆數", "Transaction", "TradeCount"]
OHLC_KEYS = {
    "open": ["開盤價", "開盤", "OpeningPrice", "Open"],
    "high": ["最高價", "最高", "HighestPrice", "High"],
    "low": ["最低價", "最低", "LowestPrice", "Low"],
    "close": ["收盤價", "收盤", "ClosingPrice", "Close"],
}


def log(s: str) -> None:
    print(f"[{datetime.now(TZ):%H:%M:%S}] {s}", flush=True)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8"
    )


def all_dates(start: date, end: date) -> list[date]:
    out, d = [], start
    while d <= end:
        out.append(d)
        d += timedelta(days=1)
    return out


def make_session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=4, connect=4, read=4, status=4,
        backoff_factor=1.3,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        raise_on_status=False
    )
    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=3,
        pool_maxsize=3
    )
    s.mount("https://", adapter)
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (compatible; SSO-Market-Data-Continuation/1.4.2)",
        "Accept": "application/json,text/plain,*/*",
        "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    })
    return s


def params_for(market: str, d: date) -> dict:
    if market == "TWSE":
        return {
            "date": d.strftime("%Y%m%d"),
            "type": "ALLBUT0999",
            "response": "json"
        }
    roc_date = f"{d.year - 1911}/{d:%m/%d}"
    return {
        "l": "zh-tw",
        "o": "json",
        "d": roc_date,
        "se": "EW",
        "s": "0,asc,0"
    }


def is_explicit_no_data(stat: str) -> bool:
    s = (stat or "").strip().lower()
    terms = [
        "沒有符合條件的資料",
        "查無資料",
        "無符合資料",
        "無資料",
        "no data",
        "no matching data"
    ]
    return any(x in s for x in terms)


def fetch_one(session: requests.Session, market: str, d: date) -> dict:
    url = TWSE_URL if market == "TWSE" else TPEX_URL
    params = params_for(market, d)

    item = {
        "market": market,
        "date": d.isoformat(),
        "url": url,
        "params": params,
        "retrieved_at": datetime.now(TZ).isoformat(),
        "http_status": None,
        "response_url": None,
        "headers": {},
        "raw": b"",
        "payload": None,
        "status": "FETCH_ERROR",
        "error": None,
    }

    try:
        referer = (
            "https://www.twse.com.tw/"
            if market == "TWSE"
            else "https://www.tpex.org.tw/"
        )

        r = session.get(
            url,
            params=params,
            headers={"Referer": referer},
            timeout=TIMEOUT
        )

        item["http_status"] = r.status_code
        item["response_url"] = r.url
        item["raw"] = r.content or b""
        item["headers"] = {
            k: v for k, v in r.headers.items()
            if k.lower() in (
                "content-type", "content-length", "date",
                "last-modified", "etag", "cache-control"
            )
        }

        if not r.content:
            item["status"] = "EMPTY_HTTP_BODY"
            item["error"] = "官方回應空白"
            return item

        if r.content.lstrip()[:30].lower().startswith(
            (b"<!doctype html", b"<html")
        ):
            item["status"] = "HTML_NOT_JSON"
            item["error"] = "HTTP 回應是 HTML，不是 JSON"
            return item

        try:
            payload = r.json()
        except Exception as e:
            item["status"] = "JSON_PARSE_ERROR"
            item["error"] = f"{type(e).__name__}: {e}"
            return item

        item["payload"] = payload

        if r.status_code >= 400:
            item["status"] = "HTTP_ERROR"
            item["error"] = f"HTTP {r.status_code}: {r.text[:500]}"
            return item

        stat = str(payload.get("stat", "")) if isinstance(payload, dict) else ""

        if is_explicit_no_data(stat):
            item["status"] = "NO_DATA_RESPONSE"
            item["error"] = stat
            return item

        if not isinstance(payload, dict):
            item["status"] = "BAD_JSON_ROOT"
            item["error"] = "JSON 根節點不是 object"
            return item

        item["status"] = "FETCHED_JSON"

    except Exception as e:
        item["status"] = "FETCH_ERROR"
        item["error"] = f"{type(e).__name__}: {e}"

    return item


def norm_key(v) -> str:
    return re.sub(
        r"[\s_\-（）()：:]+",
        "",
        str(v or "")
    ).lower()


def field_match(fields, aliases):
    lookup = {norm_key(x): x for x in fields}
    for a in aliases:
        if norm_key(a) in lookup:
            return lookup[norm_key(a)]
    return None


def extract_table(payload: dict, market: str) -> dict:
    tables = payload.get("tables")

    if not isinstance(tables, list):
        if (
            isinstance(payload.get("fields"), list)
            and isinstance(payload.get("data"), list)
        ):
            tables = [payload]
        else:
            raise ValueError(f"{market} 找不到 tables 或 fields/data")

    choices = []

    for table in tables:
        if not isinstance(table, dict):
            continue

        fields = table.get("fields")
        data = table.get("data")

        if (
            not isinstance(fields, list)
            or not isinstance(data, list)
            or not fields
            or not data
        ):
            continue

        mapping = {
            "code": field_match(fields, CODE_KEYS),
            "name": field_match(fields, NAME_KEYS),
            "volume": field_match(fields, VOLUME_KEYS),
            "value": field_match(fields, VALUE_KEYS),
            "count": field_match(fields, COUNT_KEYS),
            **{
                k: field_match(fields, v)
                for k, v in OHLC_KEYS.items()
            }
        }

        if mapping["code"] and mapping["close"] and mapping["volume"]:
            choices.append((table, fields, data, mapping))

    if not choices:
        raise ValueError(
            f"{market} 找不到含代號、收盤價及成交股數的個股行情表"
        )

    table, fields, data, mapping = max(
        choices,
        key=lambda x: len(x[2])
    )

    rows, malformed = [], 0

    for values in data:
        if isinstance(values, dict):
            row = {str(k): v for k, v in values.items()}

        elif isinstance(values, (list, tuple)):
            if len(values) != len(fields):
                malformed += 1
            row = {
                str(fields[i]): (
                    values[i] if i < len(values) else ""
                )
                for i in range(len(fields))
            }

        else:
            malformed += 1
            continue

        rows.append(row)

    return {
        "rows": rows,
        "fields": [str(x) for x in fields],
        "title": str(table.get("title", "")),
        "mapping": mapping,
        "malformed": malformed
    }


def parse_date_value(value):
    if value is None:
        return None

    s = str(value).strip()
    m = re.search(
        r"(\d{3,4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日",
        s
    )

    if m:
        y, mo, dy = map(int, m.groups())
        if y < 1912:
            y += 1911
        try:
            return date(y, mo, dy).isoformat()
        except ValueError:
            return None

    digits = re.sub(r"\D", "", s)

    try:
        if len(digits) == 7:
            return date(
                int(digits[:3]) + 1911,
                int(digits[3:5]),
                int(digits[5:7])
            ).isoformat()

        if len(digits) == 8 and int(digits[:4]) >= 1912:
            return date(
                int(digits[:4]),
                int(digits[4:6]),
                int(digits[6:8])
            ).isoformat()

    except ValueError:
        return None

    return None


def payload_dates(payload: dict) -> list[str]:
    found = set()

    if not isinstance(payload, dict):
        return []

    keys = {
        norm_key(x)
        for x in [
            "date", "reportdate", "report_date",
            "datadate", "data_date", "tradedate",
            "trade_date", "資料日期", "日期"
        ]
    }

    for k, v in payload.items():
        if norm_key(k) in keys:
            p = parse_date_value(v)
            if p:
                found.add(p)

    for t in (
        payload.get("tables", [])
        if isinstance(payload.get("tables"), list)
        else []
    ):
        if isinstance(t, dict):
            for k in ("title", "date", "reportDate", "資料日期", "日期"):
                p = parse_date_value(t.get(k))
                if p:
                    found.add(p)

    return sorted(found)


def find_value(row: dict, aliases):
    lookup = {norm_key(k): v for k, v in row.items()}
    for a in aliases:
        if norm_key(a) in lookup:
            return lookup[norm_key(a)]
    return None


def num(v):
    if v is None:
        return None
    s = str(v).strip().replace(",", "").replace("元", "").replace("股", "")
    if s in ("", "-", "----", "--", "N/A", "null", "None"):
        return None
    try:
        return float(s)
    except Exception:
        return None


def row_sha(row: dict) -> str:
    raw = json.dumps(
        row,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str
    )
    return sha256_bytes(raw.encode("utf-8"))


def validate_one(item: dict) -> tuple[dict, list[dict]]:
    market, d = item["market"], item["date"]

    result = {
        "market": market,
        "trade_date": d,
        "status": item["status"],
        "passed": False,
        "row_count": 0,
        "unique_code_count": 0,
        "duplicate_code_count": 0,
        "missing_code_rows": 0,
        "zero_volume_rows": 0,
        "ohlc_missing": {},
        "response_dates": [],
        "table_title": None,
        "error": item.get("error")
    }

    closure_note = OFFICIAL_MARKET_CLOSED.get(
        date.fromisoformat(d), {}
    ).get(market)

    if item["status"] != "FETCHED_JSON":
        if closure_note:
            result["official_market_closure"] = closure_note
            if item["status"] == "NO_DATA_RESPONSE":
                result["status"] = "OFFICIAL_MARKET_CLOSED_CONFIRMED"
                result["error"] = item.get("error")
            else:
                result["status"] = "OFFICIAL_MARKET_CLOSED_API_CHECK_UNAVAILABLE"
                result["error"] = item.get("error")
        return result, []

    try:
        try:
            parsed = extract_table(item["payload"], market)

        except Exception as parse_exc:
            if closure_note:
                result["official_market_closure"] = closure_note
                result["status"] = "OFFICIAL_MARKET_CLOSED_CONFIRMED"
                result["error"] = (
                    "官方休市日；官方歷史端點未提供可解析行情表："
                    f"{type(parse_exc).__name__}: {parse_exc}"
                )
                return result, []
            raise

        if closure_note:
            result["official_market_closure"] = closure_note
            result["status"] = "OFFICIAL_CLOSURE_DATA_CONFLICT"
            result["error"] = (
                "官方市場行事曆列為休市，但官方行情端點卻回傳行情列，需人工核查"
            )
            result["row_count"] = len(parsed["rows"])
            return result, []

        rows = parsed["rows"]
        result["row_count"] = len(rows)
        result["table_title"] = parsed["title"]
        result["response_dates"] = payload_dates(item["payload"])

        if len(rows) < MIN_ROWS[market]:
            raise ValueError(
                f"資料列 {len(rows)} 低於 {MIN_ROWS[market]} 筆門檻"
            )

        if parsed["malformed"]:
            raise ValueError(
                f"有 {parsed['malformed']} 列欄位數與表頭不一致"
            )

        target = d
        if result["response_dates"] and result["response_dates"] != [target]:
            raise ValueError(
                f"回應日期 {result['response_dates']} 與查詢日期 {target} 不一致"
            )

        codes, records = [], []

        for row in rows:
            code = str(find_value(row, CODE_KEYS) or "").strip()
            name = str(find_value(row, NAME_KEYS) or "").strip()

            if code:
                codes.append(code)
            else:
                result["missing_code_rows"] += 1

            vol = num(find_value(row, VOLUME_KEYS))
            if vol == 0:
                result["zero_volume_rows"] += 1

            ohlc = {
                k: num(find_value(row, aliases))
                for k, aliases in OHLC_KEYS.items()
            }

            for k, v in ohlc.items():
                if v is None:
                    result["ohlc_missing"][k] = (
                        result["ohlc_missing"].get(k, 0) + 1
                    )

            records.append({
                "market": market,
                "trade_date": d,
                "instrument_code": code,
                "instrument_name": name,
                "volume": vol,
                "transaction_count": num(find_value(row, COUNT_KEYS)),
                "traded_value": num(find_value(row, VALUE_KEYS)),
                "open": ohlc["open"],
                "high": ohlc["high"],
                "low": ohlc["low"],
                "close": ohlc["close"],
                "source_row_sha256": row_sha(row),
                "raw_row_json": json.dumps(
                    row,
                    ensure_ascii=False,
                    sort_keys=True,
                    default=str
                )
            })

        result["unique_code_count"] = len(set(codes))
        result["duplicate_code_count"] = len(codes) - len(set(codes))
        result["passed"] = True
        result["status"] = "DATA_PASS"
        result["date_confirmation_basis"] = (
            "官方歷史端點的明確日期查詢參數"
            + (
                "；且回應 metadata 日期相符"
                if result["response_dates"]
                else "；回應未另附日期 metadata"
            )
        )

        return result, records

    except Exception as e:
        result["status"] = "DATA_VALIDATION_FAIL"
        result["error"] = f"{type(e).__name__}: {e}"
        return result, []


def archive_raw(out: Path, item: dict) -> dict:
    d = item["date"].replace("-", "")
    folder = out / "raw" / d
    folder.mkdir(parents=True, exist_ok=True)
    raw = item.get("raw") or b""

    info = {
        "market": item["market"],
        "trade_date": item["date"],
        "url": item["url"],
        "params": item["params"],
        "response_url": item.get("response_url"),
        "http_status": item.get("http_status"),
        "headers": item.get("headers"),
        "retrieved_at": item.get("retrieved_at"),
        "status": item.get("status"),
        "error": item.get("error"),
        "raw_bytes": len(raw),
        "raw_sha256": sha256_bytes(raw) if raw else None
    }

    if raw:
        gz = gzip.compress(raw, compresslevel=6, mtime=0)
        raw_path = folder / f"{item['market']}_response.json.gz"
        raw_path.write_bytes(gz)
        info["gzip_path"] = str(raw_path.relative_to(out))
        info["gzip_bytes"] = len(gz)
        info["gzip_sha256"] = sha256_bytes(gz)

    save_json(folder / f"{item['market']}_metadata.json", info)
    return info


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        path.write_text("NO_DATA\n", encoding="utf-8-sig")
        return

    fields = list(dict.fromkeys(
        k for row in rows for k in row.keys()
    ))

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(
            f,
            fieldnames=fields,
            extrasaction="ignore"
        )
        w.writeheader()
        w.writerows(rows)


def save_program_source(out: Path) -> str:
    """保存本次執行的完整原始碼；支援 %run 與整段貼入 Colab cell。"""
    target = out / "程式碼" / "SSO_v142_官方雙市場歷史行情缺口補齊.py"
    source_file = globals().get("__file__")

    if source_file:
        src = Path(source_file)
        if src.is_file():
            target.write_bytes(src.read_bytes())
            log(f"[SOURCE PASS] script={target.name} bytes={target.stat().st_size}")
            return str(target)

    try:
        ip = get_ipython()
        history = ip.history_manager.input_hist_raw
        candidates = [
            x for x in history
            if isinstance(x, str)
            and len(x) > 5000
            and "def main()" in x
            and VERSION in x
        ]

        if candidates:
            source = max(candidates, key=len)
            target.write_text(source, encoding="utf-8")
            log(f"[SOURCE PASS] notebook cell source saved bytes={target.stat().st_size}")
            return str(target)

    except Exception as exc:
        log(f"[SOURCE WARN] notebook source history unavailable: {exc}")

    note = (
        "無法自動擷取本次執行原始碼；"
        "請以本對話提供的 v1.4.2 完整程式為準。\n"
    )
    target.write_text(note, encoding="utf-8")
    log("[SOURCE WARN] original source was not captured")
    return str(target)


def mount_drive() -> None:
    if not Path("/content/drive/MyDrive").exists():
        from google.colab import drive
        drive.mount("/content/drive")

    if not PROJECT_ROOT.exists():
        raise FileNotFoundError(f"找不到專案根目錄：{PROJECT_ROOT}")

    CONTINUATION_ROOT.mkdir(parents=True, exist_ok=True)


def get_token():
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token
    try:
        from google.colab import userdata
        return userdata.get("GITHUB_TOKEN")
    except Exception:
        return None


def github_request(method: str, url: str, token: str, **kwargs):
    headers = kwargs.pop("headers", {})
    headers.update({
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "SSO-Market-Data-Continuation-v1.4.2"
    })

    r = requests.request(
        method,
        url,
        headers=headers,
        timeout=180,
        **kwargs
    )

    if r.status_code >= 400:
        raise RuntimeError(
            f"GitHub HTTP {r.status_code}: {r.text[:1000]}"
        )

    return r


def github_main_sha(token: str) -> str:
    obj = github_request(
        "GET",
        f"https://api.github.com/repos/{REPO}/git/ref/heads/main",
        token
    ).json()
    return obj["object"]["sha"]


def github_upload_file(token: str, branch: str, path: str, data: bytes) -> dict:
    url = f"https://api.github.com/repos/{REPO}/contents/{quote(path, safe='/')}"

    check = requests.get(
        url,
        params={"ref": branch},
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        },
        timeout=90
    )

    body = {
        "message": f"SSO v1.4.2 historical market-data gap archive: {Path(path).name}",
        "content": base64.b64encode(data).decode("ascii"),
        "branch": branch
    }

    if check.status_code == 200:
        body["sha"] = check.json()["sha"]
    elif check.status_code != 404:
        raise RuntimeError(
            f"GitHub preflight HTTP {check.status_code}: {check.text[:500]}"
        )

    return github_request("PUT", url, token, json=body).json()


def github_readback_sha(branch: str, path: str) -> str:
    url = (
        f"https://raw.githubusercontent.com/{REPO}/"
        f"{branch}/{quote(path, safe='/')}"
    )
    r = requests.get(url, timeout=180)
    r.raise_for_status()
    return sha256_bytes(r.content)


def create_zip(out: Path, path: Path) -> dict:
    with zipfile.ZipFile(
        path,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6
    ) as z:
        for f in sorted(out.rglob("*")):
            if f.is_file() and f.name != "GitHub與main核對結果.json":
                z.write(
                    f,
                    arcname=f"{out.name}/{f.relative_to(out).as_posix()}"
                )

    with zipfile.ZipFile(path, "r") as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"ZIP CRC fail: {bad}")

    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path)
    }


def main():
    log("=" * 105)
    log(
        f"啟動 {VERSION}｜TWSE / TPEx 官方歷史行情缺口補齊 "
        f"{START_DATE} 至 {END_DATE}"
    )
    log("只新增區間專屬封存；不修改 v1.3.8、v1.4.1、既有資料庫、模型資料或 main。")
    log("官方休市核對：2026-10-26 TWSE / TPEx 休市；不列為缺漏交易日。")

    mount_drive()

    out = CONTINUATION_ROOT / OUTPUT_NAME
    out.mkdir(parents=True, exist_ok=False)

    (out / "raw").mkdir()
    (out / "normalized").mkdir()
    (out / "reports").mkdir()
    (out / "程式碼").mkdir()

    save_program_source(out)

    days = all_dates(START_DATE, END_DATE)
    weekdays = [d for d in days if d.weekday() < 5]
    expected_trading_weekdays = [
        d for d in weekdays
        if d not in OFFICIAL_MARKET_CLOSED
    ]

    log(
        f"[RANGE] calendar_days={len(days)} "
        f"weekdays={len(weekdays)} "
        f"official_weekday_closures={len(OFFICIAL_MARKET_CLOSED)} "
        f"expected_trading_weekdays={len(expected_trading_weekdays)}"
    )

    session = make_session()
    all_items, checks, normalized = [], [], []
    lookup = {}

    for d in days:
        date_label = d.isoformat()
        log(
            f"[DATE] {date_label} "
            f"({'weekday' if d.weekday() < 5 else 'weekend'})"
        )

        day_checks = {}

        for market in ("TWSE", "TPEX"):
            item = fetch_one(session, market, d)
            result, records = validate_one(item)
            raw_meta = archive_raw(out, item)

            all_items.append({
                "item": item,
                "raw_meta": raw_meta
            })

            day_checks[market] = result
            checks.append(result)
            normalized.extend(records)
            lookup[(date_label, market)] = result

            if result["passed"]:
                log(
                    f"[DATA PASS] {market} "
                    f"rows={result['row_count']} "
                    f"unique={result['unique_code_count']} "
                    f"dup={result['duplicate_code_count']}"
                )
            else:
                log(
                    f"[{result['status']}] {market} "
                    f"HTTP={item.get('http_status')} "
                    f"error={result.get('error')}"
                )

            time.sleep(SLEEP_SECONDS)

        # 不把平日無資料回應擅自當成休市；需另以官方日曆核實。
        for market in ("TWSE", "TPEX"):
            r = day_checks[market]
            r["is_weekday"] = d.weekday() < 5

            if r["status"] == "NO_DATA_RESPONSE" and d.weekday() >= 5:
                r["calendar_interpretation"] = (
                    "週末無資料回應；若為補班交易日，官方 API 應回傳行情列"
                )
            elif r["status"] == "NO_DATA_RESPONSE" and d.weekday() < 5:
                r["calendar_interpretation"] = (
                    "平日無資料，未經官方休市日曆核實，不視為已完成"
                )
            elif r["passed"] and d.weekday() >= 5:
                r["calendar_interpretation"] = (
                    "週末有行情列，保留為可能補班交易日"
                )
            else:
                r["calendar_interpretation"] = (
                    "依官方指定日期端點回應記錄"
                )

    missing_weekdays = []

    for d in expected_trading_weekdays:
        for market in ("TWSE", "TPEX"):
            r = lookup[(d.isoformat(), market)]
            if not r["passed"]:
                missing_weekdays.append({
                    "trade_date": d.isoformat(),
                    "market": market,
                    "status": r["status"],
                    "error": r.get("error")
                })

    closure_conflicts = [
        x for x in checks
        if x.get("status") == "OFFICIAL_CLOSURE_DATA_CONFLICT"
    ]

    if closure_conflicts:
        final_status = "FAIL_OFFICIAL_CLOSURE_DATA_CONFLICT"
    elif missing_weekdays:
        final_status = "PARTIAL_EXPECTED_TRADING_DAY_DATA_GAPS_OR_API_ERRORS"
    else:
        final_status = "PASS_ALL_EXPECTED_TRADING_WEEKDAYS_BOTH_MARKETS"

    # 同日同市場原始列不刪除；僅列示重複鍵供後續處理。
    quality_by_date = []

    for d in days:
        for market in ("TWSE", "TPEX"):
            r = lookup[(d.isoformat(), market)]
            if r["passed"]:
                quality_by_date.append({
                    k: r.get(k)
                    for k in [
                        "market", "trade_date", "row_count",
                        "unique_code_count", "duplicate_code_count",
                        "missing_code_rows", "zero_volume_rows",
                        "ohlc_missing", "date_confirmation_basis"
                    ]
                })

    # CSV 日期欄位與代號均保留字串，不改寫來源列。
    write_csv(
        out / "normalized" / "雙市場逐日官方行情.csv",
        normalized
    )
    write_csv(
        out / "reports" / "逐日市場完整性.csv",
        checks
    )
    write_csv(
        out / "reports" / "平日未通過日期清單.csv",
        missing_weekdays
    )
    write_csv(
        out / "reports" / "逐日行情品質摘要.csv",
        quality_by_date
    )

    summary = {
        "version": VERSION,
        "status": final_status,
        "range_start": START_DATE.isoformat(),
        "range_end": END_DATE.isoformat(),
        "calendar_days_queried": len(days),
        "weekday_count": len(weekdays),
        "official_weekday_market_closures": [
            {
                "date": d.isoformat(),
                "markets": OFFICIAL_MARKET_CLOSED[d]
            }
            for d in sorted(OFFICIAL_MARKET_CLOSED)
            if d in days
        ],
        "expected_trading_weekdays_for_verification": len(expected_trading_weekdays),
        "market_date_requests": len(days) * 2,
        "passed_market_days": sum(1 for x in checks if x["passed"]),
        "passed_TWSE_days": sum(
            1 for x in checks
            if x["market"] == "TWSE" and x["passed"]
        ),
        "passed_TPEX_days": sum(
            1 for x in checks
            if x["market"] == "TPEX" and x["passed"]
        ),
        "normalized_quote_rows": len(normalized),
        "weekday_missing_or_failed_market_days": missing_weekdays,
        "official_closure_api_results": [
            x for x in checks
            if x.get("status", "").startswith("OFFICIAL_MARKET_CLOSED")
        ],
        "official_closure_data_conflicts": closure_conflicts,
        "weekend_data_days": [
            x for x in checks
            if x.get("passed") and not x.get("is_weekday")
        ],
        "weekend_no_data_days": [
            x for x in checks
            if x.get("status") == "NO_DATA_RESPONSE"
            and not x.get("is_weekday")
        ],
        "note": (
            "平日無資料回應一律列為未完成，沒有自行推定為休市；"
            "週末有行情列則保留作補班交易日資料。"
            "原始回應與異常列不刪除、不補值。"
        )
    }

    save_json(
        out / "reports" / "區間補齊總結.json",
        summary
    )

    readme = [
        f"# {VERSION}｜雙市場官方歷史行情缺口補齊",
        "",
        f"資料區間：{START_DATE.isoformat()} 至 {END_DATE.isoformat()}",
        f"執行時間：{RUN_TIME.isoformat()}",
        f"狀態：{final_status}",
        "",
        "## 擷取與核驗規則",
        "- TWSE、TPEx 各自使用官方指定日期歷史行情端點，逐日分別請求。",
        "- 每個日期兩市場皆獨立保存原始回應 gzip、URL、參數、HTTP 狀態、回應標頭與 SHA256。",
        "- 每個市場行情需至少 500 列，欄位至少含證券代號、收盤價及成交股數；不一致日期不會混入成功資料。",
        "- 平日沒有資料時不自行認定休市，列入未完成清單；僅對已核對的 TWSE / TPEx 官方市場開休市日曆日期採休市判定。",
        "- 本區間 2026-10-26 為兩市場官方公告休市日；仍保留該日 API 原始查詢回應作旁證。",
        "- 零成交量、OHLC 缺漏、重複代號保留原值並列示，不刪除、不補值。",
        "",
        "## 統計",
        (
            f"- 行事曆日期查詢數：{len(days)}；"
            f"平日數：{len(weekdays)}；"
            f"官方休市平日：{len(OFFICIAL_MARKET_CLOSED)}；"
            f"應交易平日：{len(expected_trading_weekdays)}；"
            f"市場日期請求：{len(checks)}。"
        ),
        (
            f"- 通過市場日期：{summary['passed_market_days']}；"
            f"TWSE：{summary['passed_TWSE_days']}；"
            f"TPEx：{summary['passed_TPEX_days']}。"
        ),
        (
            f"- 標準化行情列數：{len(normalized)}；"
            f"平日未通過市場日期：{len(missing_weekdays)}。"
        ),
        "",
        "## 資料安全",
        "只新增本次日期區間專屬封存；不修改既有版本、原始資料、正式資料庫、模型、回測結果或 GitHub main。",
    ]

    (out / "README.md").write_text(
        "\n".join(readme),
        encoding="utf-8"
    )

    zip_path = CONTINUATION_ROOT / f"{OUTPUT_NAME}.zip"
    zip_info = create_zip(out, zip_path)

    log(
        f"[ZIP PASS] {zip_info['path']} "
        f"bytes={zip_info['bytes']:,} "
        f"SHA256={zip_info['sha256']}"
    )

    github_result = {
        "attempted": False,
        "uploaded": False,
        "main_before": None,
        "main_after": None,
        "main_unchanged": None,
        "branch": None,
        "files": [],
        "error": None
    }

    token = get_token()

    if not token:
        github_result["error"] = (
            "GITHUB_TOKEN / GH_TOKEN 未設定；本次未上傳"
        )
        log("[GITHUB WARN] token missing; local archive preserved")

    else:
        try:
            github_result["attempted"] = True
            before = github_main_sha(token)
            github_result["main_before"] = before
            log(f"[GITHUB] main before={before}")

            if before != EXPECTED_MAIN_SHA:
                raise RuntimeError(
                    f"main SHA 與基準不符，停止上傳：{before}"
                )

            branch = (
                "audit/sso-market-data-continuation-v1-v142-gap-"
                f"{START_DATE:%Y%m%d}-{END_DATE:%Y%m%d}_{STAMP}"
            )

            github_request(
                "POST",
                f"https://api.github.com/repos/{REPO}/git/refs",
                token,
                json={
                    "ref": f"refs/heads/{branch}",
                    "sha": before
                }
            )

            github_result["branch"] = branch
            root = f"audit/sso-market-data-continuation-v1/{out.name}"

            upload_items = [
                (
                    f"{root}/{zip_path.name}",
                    zip_path.read_bytes()
                ),
                (
                    f"{root}/README.md",
                    (out / "README.md").read_bytes()
                ),
                (
                    f"{root}/reports/區間補齊總結.json",
                    (out / "reports" / "區間補齊總結.json").read_bytes()
                ),
            ]

            for remote, data in upload_items:
                github_upload_file(token, branch, remote, data)

                expected = sha256_bytes(data)
                actual = github_readback_sha(branch, remote)

                if actual != expected:
                    raise RuntimeError(
                        f"GitHub readback SHA mismatch: {remote}"
                    )

                github_result["files"].append({
                    "path": remote,
                    "bytes": len(data),
                    "sha256": expected,
                    "readback": "PASS"
                })

                log(f"[GITHUB PASS] {remote} readback=PASS")

            after = github_main_sha(token)
            github_result["main_after"] = after
            github_result["main_unchanged"] = after == before

            if after != before:
                raise RuntimeError(
                    f"main SHA changed unexpectedly: before={before} after={after}"
                )

            github_result["uploaded"] = True
            log(f"[GITHUB PASS] branch={branch} main unchanged=True")

        except Exception as e:
            github_result["error"] = f"{type(e).__name__}: {e}"
            log(f"[GITHUB FAIL] {github_result['error']}")

            try:
                if github_result["main_before"]:
                    github_result["main_after"] = github_main_sha(token)
                    github_result["main_unchanged"] = (
                        github_result["main_after"]
                        == github_result["main_before"]
                    )
            except Exception:
                pass

    final_record = {
        "summary": summary,
        "zip": zip_info,
        "github": github_result,
        "output_dir": str(out),
        "zip_path": str(zip_path),
        "run_time": RUN_TIME.isoformat()
    }

    final_record_path = out / "GitHub與main核對結果.json"
    save_json(final_record_path, final_record)

    # 最終紀錄本身也另行上傳並逐位元讀回；ZIP 保留此前已完成的資料摘要。
    if github_result.get("uploaded") and github_result.get("branch"):
        try:
            remote_final = (
                f"audit/sso-market-data-continuation-v1/"
                f"{out.name}/GitHub與main核對結果.json"
            )

            final_bytes = final_record_path.read_bytes()
            github_upload_file(
                token,
                github_result["branch"],
                remote_final,
                final_bytes
            )

            final_sha = sha256_bytes(final_bytes)
            final_readback = github_readback_sha(
                github_result["branch"],
                remote_final
            )

            if final_readback != final_sha:
                raise RuntimeError(
                    "最終核對紀錄 GitHub readback SHA256 不符"
                )

            main_after_final = github_main_sha(token)

            if main_after_final != EXPECTED_MAIN_SHA:
                raise RuntimeError(
                    f"最終紀錄上傳後 main SHA 異常：{main_after_final}"
                )

            github_result["final_record_uploaded"] = True
            github_result["final_record_readback"] = "PASS"
            github_result["final_record_sha256"] = final_sha
            github_result["main_after_final_record"] = main_after_final

            log("[GITHUB PASS] final record readback=PASS main unchanged=True")

        except Exception as e:
            github_result["final_record_uploaded"] = False
            github_result["final_record_error"] = (
                f"{type(e).__name__}: {e}"
            )
            log(
                "[GITHUB WARN] final record readback failed: "
                f"{github_result['final_record_error']}"
            )

        # 更新本機紀錄，保留最終紀錄的讀回結果；避免覆寫 GitHub 上剛驗證的版本。
        save_json(final_record_path, final_record)

    log(f"[FINAL] status={final_status}")
    log(
        f"[FINAL] weekday_missing_or_failed={len(missing_weekdays)} "
        f"quote_rows={len(normalized)}"
    )
    log(f"[FINAL] OUTPUT={out}")
    log(f"[FINAL] ZIP={zip_path}")
    log(f"[FINAL] ZIP SHA256={zip_info['sha256']}")
    log(
        f"[FINAL] GitHub upload={github_result['uploaded']} "
        f"main unchanged={github_result['main_unchanged']}"
    )
    log("原始資料與正式資料庫未修改。")
    log("=" * 105)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log(f"[FATAL] {type(exc).__name__}: {exc}")
        traceback.print_exc()
        raise