SSO_Market_Data_Continuation_TWSE_TPEX
v1.3.3｜五檔原始成交量證據核對 v2（來源定位修正版）

目標日期：2026-11-09
目標代號：3085, 4305, 4406, 4530, 6512

本次使用的官方行情來源 ZIP：
/content/sso_v133_source_recovered_20261110_093501/v1.3.3_官方普通股範圍與逐日行情交叉驗證_20261109_125127.zip
SHA256：48fbd3a78edcde0efbb4b39f7dc24197d55047fbac00b3b7f9a41f586d32480d
GitHub Raw：https://raw.githubusercontent.com/CHLINX/sso/audit/sso-market-data-continuation-v1-v133-upload-20261109_125725/audit/sso-market-data-continuation-v1/v1.3.3_%E5%AE%98%E6%96%B9%E6%99%AE%E9%80%9A%E8%82%A1%E7%AF%84%E5%9C%8D%E8%88%87%E9%80%90%E6%97%A5%E8%A1%8C%E6%83%85%E4%BA%A4%E5%8F%89%E9%A9%97%E8%AD%89_20261109_125127/v1.3.3_%E5%AE%98%E6%96%B9%E6%99%AE%E9%80%9A%E8%82%A1%E7%AF%84%E5%9C%8D%E8%88%87%E9%80%90%E6%97%A5%E8%A1%8C%E6%83%85%E4%BA%A4%E5%8F%89%E9%A9%97%E8%AD%89_20261109_125127.zip

稽核範圍：只讀取 v1.2.3 專屬資料夾內的 CSV / CSV.GZ / JSON / ZIP，
並與 v1.3.3 官方逐日行情來源 ZIP 的指定日期上櫃行情比對。

安全界線：
- 不呼叫 TWSE / TPEx 官方行情 API
- 不重跑八日行情
- 不掃描整個 Google Drive
- 不修改或刪除原始資料
- 不更新正式資料庫
- 所有成果只寫入 /content 與 GitHub audit branch

判讀提醒：沒有找到明確上櫃原始列，代表證據不足，不代表原始成交量為 0。
