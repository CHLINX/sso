SSO_Market_Data_Continuation_TWSE_TPEX v1.3.4｜五檔成交量證據上游來源追溯

目標日期：2026-11-09
目標代號：3085, 4305, 4406, 4530, 6512

本版只讀取：
1. /content/drive/MyDrive/看股最速適/SSO_Market_Data_Continuation_TWSE_TPEX_v1/v1.2.3_稽核結論校正與證據去循環_20261109_200337
2. 已驗證 SHA256=48fbd3a78edcde0efbb4b39f7dc24197d55047fbac00b3b7f9a41f586d32480d 的 v1.3.3 官方來源 ZIP

本版會列出來源檔、ZIP member、外層/內層 SHA256、資料列號、欄位原名及原始列內容，並掃描官方來源 ZIP 中所有可解析 CSV/JSON，而不是只檢查「官方逐日行情_公司主檔交集.csv」。

判讀限制：找到 v1.2.3 的正成交列，不等於已證明它直接來自官方 API；交集表中的零成交列，也不單獨證明舊來源錯誤。需對照原始檔位置、欄位及上游來源元資料後再判定。

安全界線：Google Drive 唯讀；不呼叫 TWSE/TPEx 行情 API；不更新資料庫；只在 /content 產生輸出；成果上傳獨立 GitHub audit branch，不修改 main。
