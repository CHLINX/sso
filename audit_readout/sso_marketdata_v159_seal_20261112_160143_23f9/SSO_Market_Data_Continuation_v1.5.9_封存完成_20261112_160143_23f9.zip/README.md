# SSO Market Data Continuation v1.5.9

## 執行結論

PASS_TWSE_PRICE_CHANGE_REPAIRED

本次為接續既有 TWSE 補正成果，不重新下載行情。

## TWSE 2026-11-11

- 官方列數：1,390
- 官方唯一代號：1,390
- TWSE root canonical：b366ce6fc4910caba953e3bff3d3cb2ed479b12ee33cf462e927f4931b22533f
- TWSE nested canonical：b366ce6fc4910caba953e3bff3d3cb2ed479b12ee33cf462e927f4931b22533f
- TWSE official canonical：b366ce6fc4910caba953e3bff3d3cb2ed479b12ee33cf462e927f4931b22533f
- TWSE price_change 逐筆補正：1,390/1,390
- TWSE root/nested/official：完全一致

## TPEx 2026-11-11

- 查詢類型：type=EW
- 修正資料：1,020 列
- 唯一代號：1,020
- 採用來源：v1.5.8_官方行情即時驗證與增量續接_20261112_143616_7dc9
- root 原始 SHA256：002f3e4e7af282945333db92c1cebc2a76bad5fb24a7058fda12e2690ed80742
- root canonical SHA256：eb4bd7a5e16831f74f6cc700c8076163d0ba4c5b782023f3858951035a31e627
- nested canonical SHA256：eb4bd7a5e16831f74f6cc700c8076163d0ba4c5b782023f3858951035a31e627

### TPEx price_change 欄位說明

本次 TPEx 原始修正 CSV 未提供 price_change 欄位。
依既有 v1.5.5 正規化規則，將此欄記錄為 None。
不自行補值、不推算、不虛構漲跌資料。

## 下游使用規則

TWSE 及 TPEx 的 2026-11-11 修正層均採完整日期替代方式。
不可將修正層與原有同日資料直接相加。

## 原始資料保護

- 不修改 v1.5.8
- 不修改 v1.5.7
- 不修改 v1.5.6
- 不修改舊 TPEx 修正資料
- 不刪除任何歷史資料
- 不修改 GitHub main

## TWSE 官方原始回應

JSON SHA256：

e4ff525e7611335616ce3d3a28b3a2efadf822f531271e26b2cb98a6e696df63

GZIP SHA256：

a67de6bb81d7e73aac3c17b8f54a8030f952924867dd86f643364262ad88e0fc
